# JohnTech Management System - Comprehensive Flowchart

## System Overview
The JohnTech Management System is a comprehensive business management solution with role-based access control, supporting Admin and Cashier roles across two branches.

---

## 🏗️ **SYSTEM ARCHITECTURE FLOWCHART**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           JOHNTECH MANAGEMENT SYSTEM                           │
│                              System Architecture                               │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Web Browser   │    │   Apache Server │    │   MySQL Database│
│                 │    │   (XAMPP)       │    │   (Port 3307)   │
│ • Login Page    │◄──►│ • PHP Engine    │◄──►│ • johntech_system│
│ • Admin Panel   │    │ • Session Mgmt  │    │ • Tables:       │
│ • Cashier POS   │    │ • Auth Control  │    │   - users       │
│ • Reports       │    │ • File Uploads  │    │   - products    │
└─────────────────┘    └─────────────────┘    │   - sales       │
                                              │   - returns     │
                                              │   - audit_logs  │
                                              └─────────────────┘
```

---

## 🔐 **AUTHENTICATION & AUTHORIZATION FLOW**

```
                    ┌─────────────────┐
                    │   User Access   │
                    │   index.php     │
                    └─────────┬───────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │   Login Form    │
                    │ Username/Pass   │
                    └─────────┬───────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ Validate Creds  │
                    │ Check Database  │
                    └─────────┬───────┘
                              │
                    ┌─────────▼───────┐
                    │ Valid Login?    │
                    └─────────┬───────┘
                              │
                    ┌─────────▼───────┐
                    │   Role Check    │
                    │ admin/cashier   │
                    └─────────┬───────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌─────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Admin     │    │   Cashier       │    │ Password Change │
│ Dashboard   │    │ POS Branch 1/2  │    │ Required        │
│ Access      │    │ Access          │    │ change_password │
└─────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 👨‍💼 **ADMIN DASHBOARD FLOW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              ADMIN DASHBOARD                                   │
│                          admin_dashboard.php                                   │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Dashboard     │    │   User Mgmt     │    │   Inventory     │    │   Reports       │
│   Statistics    │    │                 │    │   Management    │    │   & Analytics   │
│                 │    │ • Add Cashiers  │    │                 │    │                 │
│ • Net Sales     │    │ • Edit Cashiers │    │ • Add Products  │    │ • Sales History │
│ • Products Sold │    │ • Manage Roles  │    │ • Update Stock  │    │ • Branch Reports│
│ • Returns       │    │ • View Profiles │    │ • Categories    │    │ • Audit Logs    │
│ • Restock Alerts│    │ • Password Reset│    │ • Reorder Levels│    │ • Activity Logs │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │                      │
          └──────────────────────┼──────────────────────┼──────────────────────┘
                                 │                      │
                    ┌────────────▼──────────┐    ┌─────▼──────────┐
                    │    Branch Management   │    │  Settings      │
                    │                        │    │                │
                    │ • Branch Overview      │    │ • System Config│
                    │ • Branch 1 Details     │    │ • Security     │
                    │ • Branch 2 Details     │    │ • Backup       │
                    │ • Performance Metrics  │    │ • Maintenance  │
                    └────────────────────────┘    └────────────────┘
```

---

## 💰 **CASHIER POS SYSTEM FLOW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            CASHIER POS SYSTEM                                  │
│                         pos_branch1.php / pos_branch2.php                      │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Product       │    │   Shopping      │    │   Service       │    │   Payment       │
│   Selection     │    │   Cart          │    │   Fees          │    │   Processing    │
│                 │    │                 │    │                 │    │                 │
│ • Search Items  │───►│ • Add/Remove    │───►│ • Repair Fee    │───►│ • Amount Paid   │
│ • Browse Catalog│    │ • Quantity      │    │ • Service Only  │    │ • Calculate     │
│ • Check Stock   │    │ • Price Total   │    │ • Mechanic      │    │   Change        │
│ • Category Filter│    │ • Cart Summary  │    │ • Remarks       │    │ • Receipt       │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────┬───────┘
                                                                               │
                                                                               ▼
                                                                    ┌─────────────────┐
                                                                    │   Transaction   │
                                                                    │   Completion    │
                                                                    │                 │
                                                                    │ • Update Stock  │
                                                                    │ • Save Sale     │
                                                                    │ • Print Receipt │
                                                                    │ • Audit Log     │
                                                                    └─────────────────┘
```

---

## 🔄 **RETURNS MANAGEMENT FLOW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            RETURNS MANAGEMENT                                  │
│                         returns_management.php                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Return        │    │   Item          │    │   Condition     │    │   Processing    │
│   Initiation    │    │   Selection     │    │   Assessment    │    │   & Completion  │
│                 │    │                 │    │                 │    │                 │
│ • Sale Lookup   │───►│ • Select Items  │───►│ • Good/Damaged  │───►│ • Refund Amount │
│ • Transaction   │    │ • Enter Qty     │    │ • Broken        │    │ • Update Stock  │
│   History       │    │ • Verify Sale   │    │ • Inventory     │    │ • Return Record │
│ • Customer Info │    │ • Price Check   │    │   Decision      │    │ • Audit Trail   │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 📊 **INVENTORY MANAGEMENT FLOW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          INVENTORY MANAGEMENT                                  │
│                      Inventory_management.php                                  │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Product       │    │   Stock         │    │   Category      │    │   Reporting     │
│   Management    │    │   Management    │    │   Management    │    │   & Analytics   │
│                 │    │                 │    │                 │    │                 │
│ • Add Products  │    │ • Update Stock  │    │ • Create Cats   │    │ • Low Stock     │
│ • Edit Details  │    │ • Restock Items │    │ • Edit Categories│   │   Alerts        │
│ • Delete Items  │    │ • Branch Stock  │    │ • Assign Items  │    │ • Stock Reports │
│ • Bulk Import   │    │ • Transfer      │    │ • Category View │    │ • Sales Trends  │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 🔐 **SECURITY & AUDIT FLOW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            SECURITY & AUDIT SYSTEM                            │
│                        audit_log.php / security_config.php                     │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Login         │    │   User          │    │   System        │    │   Audit         │
│   Security      │    │   Actions       │    │   Monitoring    │    │   Reporting     │
│                 │    │                 │    │                 │    │                 │
│ • Password      │───►│ • All Actions   │───►│ • Failed Logins │───►│ • Activity Logs │
│   Verification  │    │   Logged        │    │ • Session Mgmt  │    │ • Security      │
│ • Session Mgmt  │    │ • Timestamp     │    │ • Access Control│    │   Reports       │
│ • Role Check    │    │ • IP Tracking   │    │ • Data Changes  │    │ • Export Data   │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 🏢 **BRANCH OPERATIONS FLOW**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            BRANCH OPERATIONS                                   │
│                     Branch 1 (Sorsogon) & Branch 2                            │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Branch 1      │    │   Branch 2      │    │   Shared        │    │   Centralized   │
│   Operations    │    │   Operations    │    │   Resources     │    │   Management    │
│                 │    │                 │    │                 │    │                 │
│ • POS System    │    │ • POS System    │    │ • Inventory     │    │ • Admin         │
│ • Local Stock   │    │ • Local Stock   │    │   Database      │    │   Dashboard     │
│ • Sales History │    │ • Sales History │    │ • User Accounts │    │ • Cross-Branch  │
│ • Returns       │    │ • Returns       │    │ • Audit System  │    │   Reports       │
│ • Cashiers      │    │ • Cashiers      │    │ • Security      │    │ • System        │
└─────────────────┘    └─────────────────┘    │   Policies      │    │   Settings      │
                                              └─────────────────┘    └─────────────────┘
```

---

## 🔄 **PASSWORD RECOVERY FLOW**

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Forgot        │    │   Security      │    │   Temporary     │    │   New Password  │
│   Password      │    │   Question      │    │   Password      │    │   Setup         │
│                 │    │                 │    │                 │    │                 │
│ • Enter Username│───►│ • Answer Q&A    │───►│ • Generate Temp │───►│ • Login with    │
│ • Click Recovery│    │ • Verify Answer │    │ • Email/SMS     │    │   Temp Password │
│ • Access Recovery│    │ • Check Attempts│    │ • Time Limited  │    │ • Force Change  │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 📱 **MOBILE RESPONSIVE DESIGN**

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Desktop       │    │   Tablet        │    │   Mobile        │
│   (1200px+)     │    │   (768-1199px)  │    │   (<768px)      │
│                 │    │                 │    │                 │
│ • Full Sidebar  │    │ • Collapsible   │    │ • Hamburger     │
│ • Wide Layout   │    │   Sidebar       │    │   Menu          │
│ • Multi-column  │    │ • Responsive    │    │ • Stack Layout  │
│   Tables        │    │   Grid          │    │ • Touch         │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 🗄️ **DATABASE STRUCTURE**

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              DATABASE SCHEMA                                   │
│                            johntech_system                                     │
└─────────────────────────────────────────────────────────────────────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   users         │    │   products      │    │   sales         │    │   sale_items    │
│                 │    │                 │    │                 │    │                 │
│ • id            │    │ • id            │    │ • id            │    │ • id            │
│ • username      │    │ • name          │    │ • branch_id     │    │ • sale_id       │
│ • password      │    │ • price         │    │ • cashier_id    │    │ • product_id    │
│ • role          │    │ • quantity      │    │ • total_amount  │    │ • quantity      │
│ • created_at    │    │ • branch_id     │    │ • created_at    │    │ • price         │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘

┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   returns       │    │   return_items  │    │   audit_logs    │    │   cashier_      │
│                 │    │                 │    │                 │    │   profiles      │
│ • id            │    │ • id            │    │ • id            │    │                 │
│ • sale_id       │    │ • return_id     │    │ • user_id       │    │ • user_id       │
│ • branch_id     │    │ • product_id    │    │ • action        │    │ • name          │
│ • total_amount  │    │ • quantity      │    │ • timestamp     │    │ • branch_id     │
│ • reason        │    │ • condition     │    │ • ip_address    │    │ • profile_pic   │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 🚀 **SYSTEM DEPLOYMENT FLOW**

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Development   │    │   Testing       │    │   Production    │    │   Maintenance   │
│   Environment   │    │   Phase         │    │   Deployment    │    │   & Updates     │
│                 │    │                 │    │                 │    │                 │
│ • Local XAMPP   │───►│ • Functionality │───►│ • Live Server   │───►│ • Regular       │
│ • Code Changes  │    │ • Security Test │    │ • Domain Setup  │    │   Backups       │
│ • Feature Dev   │    │ • User Testing  │    │ • SSL Setup     │    │ • Security      │
│ • Bug Fixes     │    │ • Performance   │    │ • Monitoring    │    │   Updates       │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 📋 **KEY FEATURES SUMMARY**

### **🔐 Authentication & Security**
- Role-based access control (Admin/Cashier)
- Secure password management with recovery
- Session management and timeout
- Comprehensive audit logging
- Security question-based recovery

### **💰 Business Operations**
- Dual-branch POS system
- Real-time inventory management
- Sales processing with service fees
- Returns and refunds management
- Comprehensive reporting and analytics

### **👥 User Management**
- Admin dashboard for system oversight
- Cashier profile management
- Mechanic assignment system
- Profile picture uploads
- Activity tracking and monitoring

### **📊 Reporting & Analytics**
- Real-time sales statistics
- Branch performance metrics
- Inventory alerts and restocking
- Audit trail and security logs
- Export capabilities for data analysis

---

## 🎯 **SYSTEM ACCESS POINTS**

| **User Type** | **Entry Point** | **Default Credentials** | **Main Functions** |
|---------------|-----------------|-------------------------|-------------------|
| **Admin** | `/index.php` | admin / JohnTech2025! | System management, reports, user control |
| **Cashier** | `/index.php` | Created by admin | POS operations, sales, returns |
| **Recovery** | `/admin_recovery.php` | Security question | Password reset functionality |

---

*This flowchart provides a comprehensive overview of the JohnTech Management System architecture, user flows, and operational processes. The system is designed for business management with emphasis on security, usability, and comprehensive functionality across multiple branches.*
